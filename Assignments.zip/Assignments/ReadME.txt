
Given a list of orders. Find top 2 most ordered item.


How to check the solution?

PROBLEM 1
 1. Open project in IDE. (Eclipse or IntelliJ IDEA)
 2. Run the Solution.java main method.
 3. It will ask for total number of orders. Enter number of orders. i.e. 4, 6, etc.
 4. For each order, it will ask for items. You can enter items with comma separated values.
 5. After entering all the items for each order, it will display top most two frequently ordered items.
    In case if two items have same highest count, it will show multiple items.


PROBLEM 2
 1. Make sure you have HSQLDB running on your pc.
 2. I have created the database with the following config. Apply the same.
    server.database.0 = file:hsqldb/demodb
    server.dbname.0 = testdb
 3. Open the project in maven based environment. INTELLIJ IDEA Recommendded.
 4. Run the SpringBootApplication Main method.
 5. In controllers > MasterController.java you will find all the corrsponding controllers to observe the project and things are pretty much self explinotory there.
-> you can run setuptable api to get dummy content.