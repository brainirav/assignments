package com.neo.problemtwo.exceptions;

public class InvalidMovieException extends Exception{
    public String toString(){
        return "Invalid Movie";
    }
}
