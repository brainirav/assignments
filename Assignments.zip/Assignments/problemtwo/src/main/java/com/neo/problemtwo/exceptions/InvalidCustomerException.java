package com.neo.problemtwo.exceptions;

public class InvalidCustomerException extends Exception{
    public String toString(){
        return "Invalid Customer";
    }
}
